'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Image from 'next/image';
import { obtener_persona, guardar_archivo, obtener_archivos, archivo_perfil } from '../hooks/servicio_persona';
import { verificarExpiracionToken } from '../hooks/utiles/sesion_utiles';
import swal from 'sweetalert';
import Menu from '../componentes/menu/menu';
import Cookies from 'js-cookie';
import { FaUpload } from 'react-icons/fa';

export default function Cuenta() {
    const router = useRouter();

    let [usuario, setUsuario] = useState(null);
    let [archivo, setArchivo] = useState(null);
    let [perfil, setPerfil] = useState(null);
    let [archivo_seleccionado, setSeleccion] = useState(null);
    const parametro = Cookies.get('external');

    console.log(parametro);

    useEffect(() => {
        if (verificarExpiracionToken(router)) {
            obtener_persona(parametro).then((respuesta) => {
                if (respuesta && respuesta.code === 200) {
                    console.log(respuesta.datos);
                    setUsuario(respuesta.datos);
                } else {
                    console.log(respuesta.datos.error);
                }
            });

            obtener_archivos(parametro).then((respuesta) => {
                if (respuesta && respuesta.code === 200) {
                    console.log(respuesta.datos);
                    setArchivo(respuesta.datos);
                } else {
                    console.log(respuesta.datos.error);
                }
            });

            archivo_perfil(parametro).then((respuesta) => {
                if (respuesta && respuesta.code === 200) {
                    console.log(respuesta);
                    setPerfil(respuesta);
                } else {
                    console.log(respuesta);
                }
            });
        }
    }, [router, parametro]);

    console.log(usuario);
    console.log(parametro);

    const subirImagen = (e) => {
        e.preventDefault();
        // Si no hay archivo seleccionado, abrir el explorador de archivos
        if (!archivo_seleccionado) {
            const inputFile = document.getElementById('archivoInput');
            if (inputFile) {
                inputFile.click();
            }
            return;
        }
        // Validación del tipo de archivo permitido
        const extensiones = ['image/png', 'image/jpeg', 'image/jpg', 'image/gif'];
        if (!extensiones.includes(archivo_seleccionado.type)) {
            swal({
                title: 'Error',
                text: 'El archivo debe ser de tipo PNG, JPG, JPEG o GIF.',
                icon: 'error',
                button: 'Aceptar',
                timer: 8000,
                closeOnEsc: true
            });
            return;
        }

        // Validación del tamaño del archivo
        const max_tamanio = 1024 * 1024; // 1MB en bytes
        if (archivo_seleccionado.size > max_tamanio) {
            swal({
                title: 'Error',
                text: 'El tamaño del archivo no debe superar 1MB.',
                icon: 'error',
                button: 'Aceptar',
                timer: 8000,
                closeOnEsc: true
            });
            return;
        }

        // Si pasa las validaciones, procede a subir el archivo
        const formData = new FormData();
        formData.append('archivo', archivo_seleccionado);
        formData.append('external', parametro);

        guardar_archivo(formData).then((respuesta) => {
            if (respuesta && respuesta.code === 200) {
                console.log('Imagen subida con éxito');
                swal({
                    title: 'INFO',
                    text: respuesta.datos.tag,
                    icon: 'success',
                    button: 'Aceptar',
                    timer: 8000,
                    closeOnEsc: true
                });
            } else {
                console.error('Error al subir la imagen:', respuesta.error);
                swal({
                    title: 'Error',
                    text: respuesta.datos.error,
                    icon: 'error',
                    button: 'Aceptar',
                    timer: 8000,
                    closeOnEsc: true
                });
            }
        });
        // actualizar la lista de imágenes 
        obtener_archivos(parametro).then((respuesta) => {
            if (respuesta && respuesta.code === 200) {
                setArchivo(respuesta.datos);
            } else {
                console.log(respuesta.datos.error);
            }
        });
    }
    
    const handleArchivoChange = (e) => {
        const arch = e.target.files[0];
        setSeleccion(arch);
    };

    return (
        <>
            <Menu></Menu>
            <div className="container mx-auto py-20">
                <div className="bg-white shadow-md rounded-lg p-6">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center text-black">
                            {perfil && (<Image src={`/${perfil.ruta_archivo}`} alt="Imagen de perfil" width={100} height={100} className="rounded-full" />)}
                            <div className="ml-4">
                                {usuario && (<h2 className="text-2xl font-bold">{usuario.nombres + ' ' + usuario.apellidos}</h2>)}
                                {usuario && (<p>{usuario.cuenta.usuario}</p>)}
                                {usuario && (<p>{usuario.rol.nombre}</p>)}
                                {usuario && (<p>{usuario.identificacion}</p>)}
                                <Link className="mr-4" href={"cuenta/" + parametro}>
                                    <p className="text-blue-500 font-bold hover:underline">Editar datos personales</p>
                                </Link>
                            </div>
                        </div>
                        <div>
                            <form className="mt-6" onSubmit={subirImagen}>
                                <div className="block text-sm font-medium text-gray-700 mb-3 text-center">
                                    <label className="block cursor-pointer">
                                        <span className='inline-block align-middle mr-4'><FaUpload size={40} /></span>
                                        <span className='inline-block align-middle mr-2'>Subir imagen</span>
                                        <input id="archivoInput" type="file" accept=".jpg, .jpeg, .gif, .png" onChange={handleArchivoChange} />
                                    </label>
                                </div>
                                <button type="submit" className="mt-5 mr-5 bg-green-500 font-bold text-white px-4 py-2 rounded mx-auto">Subir</button>
                            </form>
                        </div>
                    </div>
                    <div className="mt-6 text-black ">
                        <h3 className="text-lg font-bold">Galería de Imágenes</h3>
                        <div className="grid grid-cols-3 gap-4 mt-4">
                            {archivo && archivo.map((image, index) => (
                                <Image key={index} src={`/${+image.ruta_archivo}`} alt={`Imagen ${index + 1}`} width={300} height={100} className="rounded" />
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

