'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Menu from '../../componentes/menu/menu';
import { obtener_persona, modificar_persona } from '../../hooks/servicio_persona';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm } from 'react-hook-form';
import Cookies from 'js-cookie';
import swal from 'sweetalert';
import { verificarExpiracionToken } from '@/app/hooks/utiles/sesion_utiles';

export default function Cuenta() {
    const router = useRouter();
    const external = Cookies.get("external");
    let [usuario, setUsuario] = useState(null);

    //esquema de validacion para el formulario de persona censada
    const validacion_esquema = Yup.object().shape({
        apellidos: Yup.string().trim().matches(/^[a-zA-Z\s]+$/, 'Los apellidos solo deben contener letras').required('Ingrese sus nombres'),
        nombres: Yup.string().trim().matches(/^[a-zA-Z\s]+$/, 'Los nombres solo deben contener letras').required('Ingrese sus apellidos'),
        identificacion: Yup.string().trim().matches(/^[0-9]{10}/, 'La identificacion ingresada es incorrecta').required('Ingrese su identificacion'),
        usuario: Yup.string().trim().email('El correo ingresado es incorrecto').required('Ingrese su usuario'),
    });
    
    //opciones para el formulario
    const opciones_formulario = { resolver: yupResolver(validacion_esquema) };
    //hook para el manejo del formulario
    const { register, handleSubmit, formState } = useForm(opciones_formulario);
    //manejo de errores
    let { errors } = formState;

    useEffect(() => {
        if (verificarExpiracionToken(router)) {
            obtener_persona(external).then((respuesta) => {
                if (respuesta && respuesta.code === 200) {
                    console.log(respuesta.datos);
                    setUsuario(respuesta.datos);
                } else {
                    console.log(respuesta.datos.error);
                }
            });
        }
    }), [router, external];

    //enviar data
    const enviar_data = (data) => {
        console.log(data);
        const info = {
            "apellidos": data.apellidos,
            "nombres": data.nombres,
            "identificacion": data.identificacion,
            "usuario": data.usuario,
            "rol": "ADMINISTRADOR",
        };

        modificar_persona(external, info).then((respuesta) => {
            if (respuesta && respuesta.code == 200) {
                console.log("Persona modificada con exito");
                console.log(respuesta.data);
                swal({
                    title: "INFO",
                    text: respuesta.datos.tag,
                    icon: "success",
                    button: "Aceptar",
                    timer: 8000,
                    closeOnEsc: true
                });
                //redireccionar a la pagina de menu
                router.push('/cuenta');
            } else {
                swal({
                    title: "Error",
                    text: respuesta.datos.error,
                    icon: "error",
                    button: "Aceptar",
                    timer: 8000,
                    closeOnEsc: true
                });
                //redireccionar a misma pagina
                //router.push('/cuenta/' + external);
                //router.refresh();
                console.log("Error al modificar persona");
                console.log(respuesta);
            }
        });
    };

    const cancelar = () => {
        router.push('/cuenta');
        router.refresh();
    };

    return (
        <>
            <Menu></Menu>
            <div className="container mx-auto p-4 py-20">
                <div className="bg-white text-black shadow-md rounded-lg p-6">
                    <h2 className="text-2xl font-bold mb-4">Modificar Información Personal</h2>
                    <form onSubmit={handleSubmit(enviar_data)}>
                        <div className="mb-4">
                            <label htmlFor="nombres" className="block text-sm font-medium text-gray-700">Nombres</label>
                            <input type="text" id="nombres" defaultValue={usuario && usuario.nombres} required {...register('nombres')} />
                            { errors.nombres && <div className="text-danger mt-1">{errors.nombres?.message}</div>}
                        </div>
                        <div className="mb-4">
                            <label htmlFor="apellidos" className="block text-sm font-medium text-gray-700">Apellidos</label>
                            <input type="text" id="apellidos" defaultValue={usuario && usuario.apellidos} required {...register('apellidos')} />
                            {errors.apellidos && <div className="text-danger mt-1">{errors.apellidos?.message}</div>}
                        </div>
                        <div className="mb-4">
                            <label htmlFor="identificacion" className="block text-sm font-medium text-gray-700">Identificación</label>
                            <input type="text" id="identificacion" defaultValue={usuario && usuario.identificacion} required {...register('identificacion')} />
                            {errors.identificacion && <div className="text-danger mt-1">{errors.identificacion?.message}</div>}
                        </div>
                        <div className="mb-4">
                            <label htmlFor="usuario" className="block text-sm font-medium text-gray-700">Usuario</label>
                            <input type="text" id="usuario" defaultValue={usuario && usuario.cuenta.usuario} required {...register('usuario')} />
                            {errors.usuario && <div className="text-danger mt-1">{errors.usuario?.message}</div>}
                        </div>
                        <div className="flex justify-center mb-4">
                            <button type="submit" className="bg-green-500 text-white px-4 py-2 rounded">Modificar</button>
                        </div>
                        <div className="flex justify-center">
                            <button type="button" onClick={cancelar} className="bg-gray-500 text-white px-4 py-2 rounded">Cancelar</button>
                        </div>
                    </form>
                </div>
            </div>
        </>
    );
}