'use client';

import * as Yup from 'yup';
import Cookies from 'js-cookie';
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm } from 'react-hook-form';
import swal from 'sweetalert';
import { useRouter } from 'next/navigation';
import { inicio_sesion } from '../hooks/servicio_autenticacion';
import { FaEnvelope, FaLock } from 'react-icons/fa';

export default function Sesion() {
    const router = useRouter();

    // Esquema de validación para el formulario de inicio de sesión
    const validacion_esquema = Yup.object().shape({
        correo: Yup.string().trim().required('Ingrese su correo').email('Correo inválido').matches(/^[^\s@]+@[^\s@]+\.[^\s@]+$/, 'Correo inválido'),
        clave: Yup.string().trim().required('Ingrese su clave').min(8, 'La clave debe tener al menos 8 caracteres alfanuméricos').max(20, 'La clave no puede tener más de 20 caracteres alfanuméricos')
    });

    // Opciones para el formulario
    const opciones_formulario = { resolver: yupResolver(validacion_esquema) };

    // Hook para el manejo del formulario
    const { register, handleSubmit, formState } = useForm(opciones_formulario);

    // Manejo de errores
    const { errors } = formState;

    // Función para enviar datos
    const enviar_data = (data) => {
        const info = { "usuario": data.correo, "clave": data.clave };

        console.log(info);
        inicio_sesion(info).then((respuesta) => {
            if (respuesta.code == '200') {
                console.log("Inicio de sesión exitoso");
                console.log(respuesta);
                // Guardar token en cookies
                Cookies.set('token', respuesta.datos.token);
                // Guardar usuario en cookies
                Cookies.set('usuario', respuesta.datos.usuario);
                // Guardar expiración en cookies
                Cookies.set('expira', respuesta.datos.expira);         
                Cookies.set('external', respuesta.datos.external);
                
                swal({
                    title: "INFO",
                    text: "Hola, " + respuesta.datos.usuario,
                    icon: "success",
                    button: "Aceptar",
                    timer: 8000,
                    closeOnEsc: true
                });

                // Redireccionar a la página de panel
                router.push('/panel');
                router.refresh();
            } else {
                swal({
                    title: "Error",
                    text: respuesta.datos.error,
                    icon: "error",
                    button: "Aceptar",
                    timer: 8000,
                    closeOnEsc: true
                });
                console.log("Inicio de sesión fallido");
                console.log(respuesta);
            }
        });

    };
    return (
        <main className="flex items-center justify-center h-screen">
            <form onSubmit={handleSubmit(enviar_data)} className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4 w-80">
                <div>
                    <div className='mb-8'>
                        <h3 className='text-2xl text-center font-bold text-black'>INICIO DE SESION</h3>
                    </div>
                    <div className='mb-4 relative'>
                        <label className='text-black font-bold' htmlFor="email">Correo electronico</label>
                            <input
                                id="email"
                                name="email"
                                placeholder="hola123@hotmail.com"
                                type='email'
                                {...register('correo')}
                                className='text-black border border-gray-600 rounded px-3 py-2 pl-10 mt-1 w-full'
                            />
                            <FaEnvelope className='text-gray-500 absolute top-10 left-3' />
                        {errors.correo && <div className="text-xs inline-block py-1 px-2 rounded text-gray-800">{errors.correo?.message}</div>}
                    </div>
                    <div className='mb-10 relative'>
                        <label className='text-black font-bold' htmlFor="password">Clave</label>
                            <input
                                id="password"
                                name="password"
                                type="password"
                                placeholder="12345678"
                                {...register('clave')}
                                className='text-black border border-gray-600 rounded px-3 py-2 pl-10 mt-1 w-full'
                            />
                            <FaLock className='text-gray-500 absolute top-10 left-3' />
                        {errors.clave && <div className="text-xs inline-block py-1 px-2 rounded text-gray-800">{errors.clave?.message}</div>}
                    </div>
                    <div className='mb-4 flex justify-center'>
                        <button type='submit' className='bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline'>INICIAR SESION</button>
                    </div>
                </div>
            </form>
        </main>
    );
}
