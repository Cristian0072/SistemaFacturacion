'use client';
import * as Yup from 'yup';
import { useRouter } from 'next/navigation';
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm } from 'react-hook-form';
import { useEffect } from 'react';
import swal from 'sweetalert';
import { guardar_producto } from '@/app/hooks/servicio_producto';
import { verificarExpiracionToken } from '@/app/hooks/utiles/sesion_utiles';
import Menu from '@/app/componentes/menu/menu';

export default function Nuevo() {
    //hook para manejar la redireccion
    const router = useRouter();
    const fecha = new Date();
    const fecha_maxima = new Date(fecha.getFullYear() - 18, fecha.getMonth(), fecha.getDate());
    const fecha_minima = new Date(fecha.getFullYear() - 100, fecha.getMonth(), fecha.getDate());
    //esquema de validacion para el formulario de persona censada
    const validacion_esquema = Yup.object().shape({
        nombre: Yup.string().trim().matches(/^[a-zA-Z\s]+$/, 'El nombre solo debe contener letras').required('Ingrese el nombre del producto'),
        descripcion: Yup.string().trim().required('Ingrese la descripción del producto').max(200, 'La descripción no puede tener más de 200 caracteres'),
        marca: Yup.string().trim().required('Ingrese la marca del producto').max(50, 'La marca no puede tener más de 50 caracteres'),
        fecha_expiracion: Yup.date().min(fecha_minima, 'La fecha de expiracion es incorrecta').required('Ingrese la fecha de expiración del producto'),
        fecha_fabricacion: Yup.date().min(fecha_maxima, 'La fecha de fabricacion es incorrecta').required('Ingrese la fecha de fabricación del producto'),
        codigo: Yup.string().trim().required('Ingrese el código del producto').max(20, 'El código no puede tener más de 20 caracteres'),
        cantidad_stock: Yup.number().required('Ingrese la cantidad de stock del producto').min(1, 'La cantidad de stock no puede ser menor a 1'),
    });
    //opciones para el formulario
    const opciones_formulario = { resolver: yupResolver(validacion_esquema) };
    //hook para el manejo del formulario
    const { register, handleSubmit, formState } = useForm(opciones_formulario);
    //manejo de errores
    let { errors } = formState;
    //hook para manejar el efecto de la pagina al listar los estados civiles
    useEffect(() => {
        if (verificarExpiracionToken(router)) {
        }
    }, [router]);
    // Función para formatear fechas a dd/mm/aaaa
    const formatearFecha = (fecha) => {
        const date = new Date(fecha);
        const dia = date.getDate().toString().padStart(2, '0');
        const mes = (date.getMonth() + 1).toString().padStart(2, '0'); // Los meses en JavaScript empiezan desde 0
        const año = date.getFullYear();
        return `${dia}/${mes}/${año}`;
    };
    //enviar data
    const enviar_data = (data) => {

        console.log(data);
        const info = {
            "nombre": data.nombre,
            "descripcion": data.descripcion,
            "marca": data.marca,
            "fecha_expiracion": formatearFecha(data.fecha_expiracion),
            "fecha_fabricacion": formatearFecha(data.fecha_fabricacion),
            "codigo": data.codigo,
            "cantidad_stock": data.cantidad_stock
        };
        // Convertir fecha de nacimiento a formato yyyy-mm-dd

        //enviamos la data al servicio de guardar persona --> censado
        guardar_producto(info).then((respuesta) => {
            if (respuesta && respuesta.code == 200) {
                console.log("Persona registrada con exito");
                console.log(respuesta.data);
                swal({
                    title: "INFO",
                    text: respuesta.data.tag,
                    icon: "success",
                    button: "Aceptar",
                    timer: 8000,
                    closeOnEsc: true
                });
                //redireccionar a la pagina de menu
                router.push('/producto');
                router.refresh();
            } else {
                swal({
                    title: "Error",
                    text: respuesta.datos.error,
                    icon: "error",
                    button: "Aceptar",
                    timer: 8000,
                    closeOnEsc: true
                });
                //redireccionar a misma pagina
                router.push('/producto/nuevo');
                router.refresh();
                console.log("Error al crear persona");
                console.log(respuesta);
            }
        });
    };
    return (
        <>
            <Menu />
            <div className="container text-center py-20">
                <div className="card">
                    <div className="card-body">
                        <main className="container text-center mt-3">
                            <form onSubmit={handleSubmit(enviar_data)}>
                                <div className="text-center mb-4">
                                    <h1 className="h3 mb-3 font-bold">REGISTRAR PRODUCTO</h1>
                                </div>
                                <div className="form-floating mb-3">
                                    <label htmlFor="inputNombre" className='form-label mr-3'>Nombre</label>
                                    <input
                                        type="text"
                                        id="inputNombre"
                                        className="form-control rounded-3 text-black"
                                        placeholder="Nombre"
                                        required
                                        {...register('nombre')}
                                    />
                                    {errors.nombre && <div className="text-danger mt-1">{errors.nombre?.message}</div>}
                                </div>
                                <div className="form-floating mb-3">
                                    <label htmlFor="inputMarca" className='form-label mr-3'>Marca</label>
                                    <input
                                        type="text"
                                        id="inputMarca"
                                        className="form-control rounded-3 text-black"
                                        placeholder="Marca"
                                        required
                                        {...register('marca')}
                                    />
                                    {errors.marca && <div className="text-danger mt-1">{errors.marca?.message}</div>}
                                </div>
                                <div className="row g-2">
                                    <div className="form-floating mb-3 col-md">
                                        <label htmlFor="inputFechaExp" className='form-label mr-3'>Fecha de expiración</label>
                                        <input
                                            type="date"
                                            id="inputFechaExp"
                                            className="form-control rounded-3 text-black"
                                            placeholder="Fecha de expiración"
                                            required
                                            {...register('fecha_expiracion')}
                                        />
                                        {errors.fecha_expiracion && <div className="text-danger mt-1">{errors.fecha_expiracion?.message}</div>}
                                    </div>
                                    <div className="form-floating mb-3 col-md">
                                        <label htmlFor="inputFechaFabri" className='form-label mr-3'>Fecha de fabricación</label>
                                        <input
                                            type="date"
                                            id="inputFechaFabri"
                                            className="form-control rounded-3 text-black"
                                            placeholder="Fecha de fabricación"
                                            required
                                            {...register('fecha_fabricacion')}
                                        />
                                        {errors.fecha_fabricacion && <div className="text-danger mt-1">{errors.fecha_fabricacion?.message}</div>}
                                    </div>
                                </div>
                                <div className="row g-2">
                                    <div className="form-floating mb-3 col-md">
                                        <label htmlFor="inputCantidad" className='form-label mr-3'>Cantidad en stock</label>
                                        <input
                                            type="number"
                                            id="inputCantidad"
                                            className="form-control rounded-3 text-black"
                                            placeholder="Cantidad en stock"
                                            required
                                            {...register('cantidad_stock')}
                                        />
                                        {errors.cantidad_stock && <div className="text-danger mt-1">{errors.cantidad_stock?.message}</div>}
                                    </div>
                                    <div className="form-floating mb-3 col-md">
                                        <label htmlFor="inputCodigo" className='form-label mr-3'>Código</label>
                                        <input
                                            id="inputCodigo"
                                            className="form-control rounded-3 text-black"
                                            rows="3"
                                            placeholder="Código de producto"
                                            required
                                            {...register('codigo')}
                                        />
                                        {errors.codigo && <div className="text-danger mt-1">{errors.codigo?.message}</div>}
                                    </div>
                                </div>
                                <div className="form-floating mb-3">
                                    <label htmlFor="inputDescripcion" className='form-label mr-3'>Descripción</label>
                                    <textarea
                                        type="text"
                                        id="inputDescripcion"
                                        className="form-control rounded-3 text-black pw-full"
                                        placeholder="Descripción de producto"
                                        required
                                        {...register('descripcion')}
                                    ></textarea>
                                    {errors.descripcion && <div className="text-danger mt-1">{errors.descripcion?.message}</div>}
                                </div>
                                <div className="row mt-4 justify-content-around">
                                    <div className="col-md-5">
                                        <button className="btn btn-success btn-block rounded-3" type="submit" style={{ height: '50px', width: '200px' }}>Guardar</button>
                                    </div>
                                    <div className="col-md-5">
                                        <button className="btn btn-secondary btn-block rounded-3" type="button" style={{ height: '50px', width: '200px' }} onClick={() => router.push('/producto')}>Cancelar</button>
                                    </div>
                                </div>
                            </form>
                        </main>
                    </div>
                </div>
            </div>
        </>
    );

}    