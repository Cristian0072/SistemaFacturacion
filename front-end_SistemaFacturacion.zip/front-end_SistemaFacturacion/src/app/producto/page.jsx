//nspage
//use client es para usar y realizar eventos dentro de la pantalla del cliente
'use client';
import Menu from '../componentes/menu/menu'
import { listar_productos_estado } from '../hooks/servicio_producto';
import { useState, useEffect } from 'react';
import { verificarExpiracionToken } from '../hooks/utiles/sesion_utiles';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { formatoFecha } from '../hooks/utiles/utils';

//solo se exporta esta funcion
export default function Producto() {
    const router = useRouter();
    //variable de estado para guardar la persona
    let [producto, setProducto] = useState(null);
    let [estado, setEstado] = useState({ "estado": "BUENO" });

    //hook para manejar el efecto de la pagina al listar las personas
    useEffect(() => {
        // Función para listar personas, se ejecuta solo una vez al cargar el componente
        if (verificarExpiracionToken(router)) {
            listar_productos_estado(estado).then((respuesta) => {
                if (respuesta && respuesta.code === 200) {
                    console.log(respuesta.datos);
                    setProducto(respuesta.datos);
                } else {
                    console.log(respuesta.datos.error);
                }
            });
        }
    }, [estado, router]); // Dependencia de efecto: router
    //cambiar estado segun la seleccion
    const cambiarEstado = (nuevoEstado) => {
        setEstado({ "estado": nuevoEstado.target.value });
    };
    //pre-renederizado de la pagina
    return (
        <>
            <Menu></Menu>
            <div className="font-bold py-20 px-20">
                <a className="mr-3">Mostrar productos:</a>
                <select
                    className="form-select form-select-sm text-black rounded-md"
                    value={estado.estado}
                    onChange={cambiarEstado}
                >
                    <option value="BUENO">BUENOS</option>
                    <option value="CADUCADO">CADUCADOS</option>
                </select>
            </div>
            <div className="card px-20">
                <div className="card-header mb-2">
                    <h3 className="text-center font-bold">LISTA DE PRODUCTOS</h3>
                </div>
                <div className='btn-group rounded mb-1'>
                <Link href={"producto"} className='btn btn-outline-success custom-btn mr-2'>
                        Producto
                    </Link>
                    <Link href={"producto/nuevo"} className='btn btn-outline-success custom-btn mr-2'>
                        Registrar
                    </Link>
                    <Link href="" className='btn btn-outline-success disabled mr-2' aria-disabled="true">
                        Modificar
                    </Link>
                </div>
                <div className="card-body">
                    <div className="table-responsive">
                        <table className="table table-bordered table-striped">
                            <thead className="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Producto</th>
                                    <th>Fecha de fabricacion</th>
                                    <th>Fecha de expiracion</th>
                                    <th>Cantidad en stock</th>
                                    <th>Marca</th>
                                    <th>Codigo</th>
                                    <th>Descripcion</th>
                                    <th>Estado</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody className='table-group-divider'>
                                {producto && producto.map((dato, i) => (
                                    <tr key={i}>
                                        <td>{i + 1}</td>
                                        <td>{dato.nombre}</td>
                                        <td>{formatoFecha(dato.lote[0].fecha_fabricacion)}</td>
                                        <td>{formatoFecha(dato.lote[0].fecha_expiracion)}</td>
                                        <td>{dato.cantidad_stock}</td>
                                        <td>{dato.marca}</td>
                                        <td>{dato.codigo}</td>
                                        <td>{dato.descripcion}</td>
                                        <td>{dato.estado}</td>
                                        <td><Link href={'producto/' + dato.external_id}>
                                            <button className='btn btn-primary'>Modificar</button>
                                        </Link>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </>
    )
}