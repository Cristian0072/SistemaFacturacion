'use client';
import * as Yup from 'yup';
import { useRouter } from 'next/navigation';
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm } from 'react-hook-form';
import swal from 'sweetalert';
import Menu from '@/app/componentes/menu/menu';
import { useEffect, useState } from 'react';
import { obtener_producto } from '@/app/hooks/servicio_producto';
import { modificar_producto } from '@/app/hooks/servicio_producto';
import { verificarExpiracionToken } from '@/app/hooks/utiles/sesion_utiles';

export default function Modificar(parametro) {
    console.log(parametro.params.external);
    const router = useRouter();
    //variable de estado para guardar la persona
    let [producto, setProducto] = useState(null);

    //listar personas y estado civil
    useEffect(() => {
        if (verificarExpiracionToken(router)) {
            //obtener persona por external
            obtener_producto(parametro.params.external).then((respuesta) => {
                console.log(respuesta);
                //si la respuesta es correcta
                if (respuesta && respuesta.code == 200) {
                    console.log("*******************", respuesta.datos);
                    setProducto(respuesta.datos);
                } else {
                    console.log(respuesta.datos.error);
                }
            });
        }
    }, [parametro, router]);

    const fecha = new Date();

    //esquema de validacion para el formulario de persona censada
    const validacion_esquema = Yup.object().shape({
        nombre: Yup.string().trim().matches(/^[a-zA-Z\s]+$/, 'El nombre solo debe contener letras').required('Ingrese el nombre del producto'),
        descripcion: Yup.string().trim().required('Ingrese la descripción del producto').max(200, 'La descripción no puede tener más de 200 caracteres'),
        marca: Yup.string().trim().required('Ingrese la marca del producto').max(50, 'La marca no puede tener más de 50 caracteres'),
        fecha_expiracion: Yup.date().min(fecha, 'La fecha de expiración debe ser mayor a la fecha actual').required('Ingrese la fecha de expiración del producto'),
        fecha_fabricacion: Yup.date().max(fecha, 'La fecha de fabricación no puede ser mayor a la fecha actual').required('Ingrese la fecha de fabricación del producto'),
        codigo: Yup.string().trim().required('Ingrese el código del producto').max(20, 'El código no puede tener más de 20 caracteres'),
        cantidad_stock: Yup.number().required('Ingrese la cantidad de stock del producto').min(1, 'La cantidad de stock no puede ser menor a 1'),
    });
    //opciones para el formulario
    const opciones_formulario = { resolver: yupResolver(validacion_esquema) };
    //hook para el manejo del formulario
    const { register, handleSubmit, formState } = useForm(opciones_formulario);
    //manejo de errores
    let { errors } = formState;

    //enviar data
    const enviar_data = (data) => {
        console.log(data);
        const info = {
            "nombre": data.nombre,
            "descripcion": data.descripcion,
            "marca": data.marca,
            "fecha_expiracion": producto.lote[0].fecha_expiracion,
            "fecha_fabricacion": producto.lote[0].fecha_fabricacion,
            "codigo": producto.codigo,
            "cantidad_stock": data.cantidad_stock,
            "external": producto.external_id
        };

        modificar_producto(info).then((respuesta) => {
            if (respuesta.code == 200) {
                console.log("Persona modificada con exito");
                console.log(respuesta.data);
                swal({
                    title: "INFO",
                    text: respuesta.data.tag,
                    icon: "success",
                    button: "Aceptar",
                    timer: 8000,
                    closeOnEsc: true
                });
                //redireccionar a la pagina de menu
                router.push('/producto');
                router.refresh();
            } else {
                swal({
                    title: "Error",
                    text: respuesta.datos.error,
                    icon: "error",
                    button: "Aceptar",
                    timer: 8000,
                    closeOnEsc: true
                });
                //redireccionar a misma pagina
                //router.push('/producto/'+producto.external_id);
                router.refresh();
                console.log("Error al modificar persona");
                console.log(respuesta);
            }
        });
    };
    //<input type="hidden" defaultValue={producto.external_id}/>
    //ocultar external de la vista 
    //vista del formulario
    return (
        <>
            <Menu></Menu>
            <main className="container text-center mt-5 py-20">
                <form onSubmit={handleSubmit(enviar_data)}>
                    <div className="text-center mb-4">
                        <h1 className="h3 mb-3 font-bold">MODIFICAR PRODUCTO</h1>
                    </div>
                    <div className="input-box mb-3">
                        <label htmlFor="inputNombre" className='form-label'>Nombre</label>
                        <input type="text" id="inputNombre" className="form-control text-black" placeholder="Nombre" required {...register('nombre')} defaultValue={producto && producto.nombre} />
                        {errors.nombre && <div className="text-danger mt-1">{errors.nombre?.message}</div>}
                    </div>
                    <div className="input-box mb-3">
                        <label htmlFor="inputMarca" className='form-label'>Marca</label>
                        <input type="text" id="inputMarca" className="form-control text-black" placeholder="Marca" required {...register('marca')} defaultValue={producto && producto.marca} />
                        {errors.marca && <div className="text-danger mt-1">{errors.marca?.message}</div>}
                    </div>
                    <div className="input-box mb-3">
                        <label htmlFor="inputDescripcion" className='form-label'>Descripcion</label>
                        <textarea type="text" id="inputDescripcion" className="form-control text-black pw-full" placeholder="Descripcion de producto" required {...register('descripcion')} defaultValue={producto && producto.descripcion} ></textarea>
                        {errors.descripcion && <div className="text-danger mt-1">{errors.descripcion?.message}</div>}
                    </div>
                    <div className="input-box mb-3">
                        <label htmlFor="inputCantidad" className='form-label'>Cantidad en stock</label>
                        <input type="number" id="inputCantidad" className="form-control text-black" placeholder="Cantidad en stock" required {...register('cantidad_stock')} defaultValue={producto && producto.cantidad_stock} />
                        {errors.cantidad_stock && <div className="text-danger mt-1">{errors.cantidad_stock?.message}</div>}
                    </div>

                    <div className="row mt-5">
                        <div className="col-md-6">
                            <button className="w-100 btn btn-sm btn-success" type="submit" style={{ width: '20px', height: '40px' }}>Modificar</button>
                        </div>
                        <div className="col-md-6">
                            <button className="w-100 btn btn-sm btn-secondary" type="button" style={{ width: '20px', height: '40px' }} onClick={() => router.push('/producto')}>Cancelar</button>
                        </div>
                    </div>
                </form>
            </main>
        </>
    );
}