//nspage
'use client';

import Menu from '../componentes/menu/menu';

//solo se exporta esta funcion
export default function Panel() {
    return (
        <div>
            <Menu></Menu>
        </div>

    )
}