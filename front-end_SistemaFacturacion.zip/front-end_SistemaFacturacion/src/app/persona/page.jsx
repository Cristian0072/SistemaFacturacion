//nspage
//use client es para usar y realizar eventos dentro de la pantalla del cliente
'use client';
import Menu from '../componentes/menu/menu'
import { listar_personas } from '../hooks/servicio_persona';
import { useState, useEffect } from 'react';
import { verificarExpiracionToken } from '../hooks/utiles/sesion_utiles';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

//solo se exporta esta funcion
export default function Persona() {
    const router = useRouter();
    //variable de estado para guardar la persona
    let [persona, setPersona] = useState(null);
    //hook para manejar el efecto de la pagina al listar las personas
    useEffect(() => {
        // Función para listar personas, se ejecuta solo una vez al cargar el componente
        if (verificarExpiracionToken(router)) {
            listar_personas().then((respuesta) => {
                if (respuesta && respuesta.code === 200) {
                    console.log(respuesta.datos);
                    setPersona(respuesta.datos);
                } else {
                    console.log(respuesta.datos.error);
                }
            });
        }
    }, [router]); // Dependencia de efecto: router


    //pre-renederizado de la pagina
    return (
        <>
            <Menu></Menu>
            <div className="card px-20 py-20">
                <div className="card-header mb-2">
                    <h3 className="text-center font-bold">LISTA DE PERSONAS</h3>
                </div>
                <div className='btn-group rounded mb-1' role="toolbar">
                    <Link href={"persona"} className='btn btn-outline-success custom-btn mr-2'>
                        Persona
                    </Link>
                    <Link href={"persona/nueva"} className='btn btn-outline-success custom-btn mr-2'>
                        Registrar
                    </Link>
                    <Link href="" className='btn btn-outline-success disabled mr-2' aria-disabled="true">
                        Modificar
                    </Link>
                </div>
                <div className="card-body">
                    <div className='table-responsive'>
                        <table className="table table-bordered table-striped">
                            <thead className="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Usuario</th>
                                    <th>Correo</th>
                                    <th>Rol</th>
                                    <th>Identificacion</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody className='table-group-divider'>
                                {persona && persona.map((dato, i) => (
                                    <tr key={i}>
                                        <td>{i + 1}</td>
                                        <td>{dato.apellidos} {dato.nombres}</td>
                                        <td>{dato.cuenta.usuario}</td>
                                        <td>{dato.rol.nombre}</td>
                                        <td>{dato.identificacion}</td>
                                        <td><Link href={'persona/' + dato.external_id} className='btn btn-primary'>Modificar</Link></td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </>
    )
}