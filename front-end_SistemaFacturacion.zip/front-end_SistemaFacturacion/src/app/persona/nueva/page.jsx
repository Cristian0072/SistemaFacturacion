'use client';
import * as Yup from 'yup';
import { useRouter } from 'next/navigation';
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm } from 'react-hook-form';
import { useEffect } from 'react';
import swal from 'sweetalert';
import { guardar_persona } from '@/app/hooks/servicio_persona';
import { verificarExpiracionToken } from '@/app/hooks/utiles/sesion_utiles';
import Menu from '@/app/componentes/menu/menu';

export default function Nueva() {
    //hook para manejar la redireccion
    const router = useRouter();

    //esquema de validacion para el formulario de persona censada
    const validacion_esquema = Yup.object().shape({
        apellidos: Yup.string().trim().matches(/^[a-zA-Z\s]+$/, 'Los apellidos solo deben contener letras').required('Ingrese sus nombres'),
        nombres: Yup.string().trim().matches(/^[a-zA-Z\s]+$/, 'Los nombres solo deben contener letras').required('Ingrese sus apellidos'),
        identificacion: Yup.string().trim().matches(/^[0-9]{10}/, 'La identificacion ingresada es incorrecta').required('Ingrese su identificacion'),
        usuario: Yup.string().trim().email('El correo ingresado es incorrecto').required('Ingrese su usuario'),
        clave: Yup.string().trim().matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,30}$/, 'La clave debe tener al menos una letra mayúscula, una letra minúscula, un número, un signo y tener entre 8 y 30 caracteres').max(30, 'La clave no puede tener mas de 30 caracteres alfanumericos').min(8, 'La clave no puede tener menos de 8 caracteres alfanumericos').required('Ingrese su clave'),
    });
    //opciones para el formulario
    const opciones_formulario = { resolver: yupResolver(validacion_esquema) };
    //hook para el manejo del formulario
    const { register, handleSubmit, formState } = useForm(opciones_formulario);
    //manejo de errores
    let { errors } = formState;
    //hook para manejar el efecto de la pagina al listar los estados civiles
    useEffect(() => {
        if (verificarExpiracionToken(router)) {
        }
    }, [router]);

    //enviar data
    const enviar_data = (data) => {

        console.log(data);
        const info = {
            "apellidos": data.apellidos,
            "nombres": data.nombres,
            "identificacion": data.identificacion,
            "usuario": data.usuario,
            "clave": data.clave,
            "rol": "USUARIO",
        };
        // Convertir fecha de nacimiento a formato yyyy-mm-dd

        //enviamos la data al servicio de guardar persona --> censado
        guardar_persona(info).then((respuesta) => {
            if (respuesta && respuesta.code == 200) {
                console.log("Persona registrada con exito");
                console.log(respuesta.data);
                swal({
                    title: "INFO",
                    text: respuesta.datos.tag,
                    icon: "success",
                    button: "Aceptar",
                    timer: 8000,
                    closeOnEsc: true
                });
                //redireccionar a la pagina de menu
                router.push('/persona');
                router.refresh();
            } else {
                swal({
                    title: "Error",
                    text: respuesta.datos.error,
                    icon: "error",
                    button: "Aceptar",
                    timer: 8000,
                    closeOnEsc: true
                });
                //redireccionar a misma pagina
                router.push('/persona/nueva');
                router.refresh();
                console.log("Error al crear persona");
                console.log(respuesta);
            }
        });
    };

    return (
        <>
            <Menu></Menu>
            <main className="container mx-auto text-center py-20">
                <form onSubmit={handleSubmit(enviar_data)}>
                    <div className="text-center mb-4">
                        <h1 className="h3 mb-3 font-bold">REGISTRAR PERSONA</h1>
                    </div>
                    <div className="form-floating mb-3">
                        <label htmlFor="inputNombres" className='form-label mr-3'>Nombres</label>
                        <input type="text" id="inputNombres" className="form-control text-black" placeholder="Nombres" required {...register('nombres')} />
                        {errors.nombres && <div className="text-danger mt-1">{errors.nombres?.message}</div>}
                    </div>
                    <div className="form-floating mb-3">
                        <label htmlFor="inputApellidos" className='form-label mr-3'>Apellidos</label>
                        <input type="text" id="inputApellidos" className="form-control text-black" placeholder="Apellidos" required {...register('apellidos')} />
                        {errors.apellidos && <div className="text-danger mt-1">{errors.apellidos?.message}</div>}
                    </div>
                    <div className="form-floating mb-3">
                        <label htmlFor="inputIdentificacion" className='form-label mr-3'>Identificacion</label>
                        <input type="text" id="inputIdentificacion" className="form-control text-black" placeholder="Identificacion" required {...register('identificacion')} />
                        {errors.identificacion && <div className="text-danger mt-1">{errors.identificacion?.message}</div>}
                    </div>
                    <div className="form-floating mb-3">
                        <label htmlFor="inputUsuario" className='form-label mr-3'>Correo electronico</label>
                        <input type="email" id="inputUsuario" className="form-control text-black" placeholder="ejemplo123@gmail.com" required {...register('usuario')} />
                        {errors.usuario && <div className="text-danger mt-1">{errors.usuario?.message}</div>}
                    </div>
                    <div className="form-floating mb-20">
                        <label htmlFor="inputClave" className='form-label mr-3'>Clave</label>
                        <input type="password" id="inputClave" className="form-control text-black" placeholder="123456789" required {...register('clave')} />
                        {errors.clave && <div className="text-danger mt-1">{errors.clave?.message}</div>}
                    </div>

                    <div className="flex justify-center mb-3">
                        <button className="bg-green-500 text-white px-4 py-2 rounded" type="submit">Guardar</button>
                    </div>
                    <div className="flex justify-center">
                        <button className="bg-gray-500 text-white px-4 py-2 rounded" type="button" onClick={() => router.push('/persona')}>Cancelar</button>
                    </div>
                </form>
            </main>
        </>
    );
}