'use client';
import * as Yup from 'yup';
import { useRouter } from 'next/navigation';
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm } from 'react-hook-form';
import swal from 'sweetalert';
import Menu from '@/app/componentes/menu/menu';
import { useEffect, useState } from 'react';
import { obtener_persona } from '@/app/hooks/servicio_persona';
import { modificar_persona } from '@/app/hooks/servicio_persona';
import { verificarExpiracionToken } from '@/app/hooks/utiles/sesion_utiles';

export default function Modificar(parametro ) {
    const router = useRouter();
    //variable de estado para guardar la persona
    let [persona, setPersona] = useState(null);

    //listar personas y estado civil
    useEffect(() => {
        if (verificarExpiracionToken(router)) {
            //obtener persona por external
            obtener_persona(parametro.params.external).then((respuesta) => {
                console.log(respuesta);
                //si la respuesta es correcta
                if (respuesta && respuesta.code == 200) {
                    setPersona(respuesta.datos);
                } else {
                    console.log(respuesta.datos.error);
                }
            });
        }
    }, [parametro, router]);

    //esquema de validacion para el formulario de persona censada
    const validacion_esquema = Yup.object().shape({
        apellidos: Yup.string().trim().matches(/^[a-zA-Z\s]+$/, 'Los apellidos solo deben contener letras').required('Ingrese sus nombres'),
        nombres: Yup.string().trim().matches(/^[a-zA-Z\s]+$/, 'Los nombres solo deben contener letras').required('Ingrese sus apellidos'),
        identificacion: Yup.string().trim().matches(/^[0-9]{10}/, 'La identificacion ingresada es incorrecta').required('Ingrese su identificacion'),
    });
    //opciones para el formulario
    const opciones_formulario = { resolver: yupResolver(validacion_esquema) };
    //hook para el manejo del formulario
    const { register, handleSubmit, formState } = useForm(opciones_formulario);
    //manejo de errores
    let { errors } = formState;

    //enviar data
    const enviar_data = (data) => {
        console.log(data);
        const info = {
            "apellidos": data.apellidos,
            "nombres": data.nombres,
            "identificacion": data.identificacion,
            "usuario": persona.cuenta.usuario,
            "rol": "USUARIO",
        };

        modificar_persona(persona.external_id,info).then((respuesta) => {
            if (respuesta && respuesta.code == 200) {
                console.log("Persona modificada con exito");
                console.log(respuesta.datos);
                swal({
                    title: "INFO",
                    text: respuesta.datos.tag,
                    icon: "success",
                    button: "Aceptar",
                    timer: 8000,
                    closeOnEsc: true
                });
                //redireccionar a la pagina de menu
                router.push('/persona');
                router.refresh();
            } else {
                swal({
                    title: "Error",
                    text: respuesta.datos.error,
                    icon: "error",
                    button: "Aceptar",
                    timer: 8000,
                    closeOnEsc: true
                });
                //redireccionar a misma pagina
                //router.push('/persona/'+parametro.params.external);
                router.refresh();
                console.log("Error al modificar persona");
                console.log(respuesta);
            }
        });
    };
    //<label htmlFor="estadoCivil">Estado Civil</label> crear un label para el select
    //vista del formulario
    return (
        <>
            <Menu></Menu>
            <main className="container text-center mt-5 py-20">
                <form onSubmit={handleSubmit(enviar_data)}>
                    <div className="text-center mb-4">
                        <h1 className="h3 mb-3 font-bold">MODIFICAR PERSONA</h1>
                    </div>
                    <div className="input-box mb-3">
                        <label htmlFor="inputNombres" className='form-label mr-3'>Nombres</label>
                        <input type="text" id="inputNombres" className="form-control text-black" placeholder="Nombres"  {...register('nombres')} required defaultValue={persona && persona.nombres} />
                        {errors.nombres && <div className="text-danger mt-1">{errors.nombres?.message}</div>}
                    </div>
                    <div className="input-box mb-3">
                        <label htmlFor="inputApellidos" className='form-label mr-3'>Apellidos</label>
                        <input type="text" id="inputApellidos" className="form-control text-black" placeholder="Apellidos"  {...register('apellidos')} required defaultValue={persona && persona.apellidos} />
                        {errors.apellidos && <div className="text-danger mt-1">{errors.apellidos?.message}</div>}
                    </div>
                    <div className="input-box mb-20">
                        <label htmlFor="inputIdentificacion" className='form-label mr-3'>Identificacion</label>
                        <input type="text" id="inputIdentificacion" className="form-control text-black" placeholder="Identificacion"  {...register('identificacion')} required defaultValue={persona && persona.identificacion} />
                        {errors.identificacion && <div className="text-danger mt-1">{errors.identificacion?.message}</div>}
                    </div>
                        <div className="flex justify-center mb-3">
                            <button className="bg-green-500 text-white px-4 py-2 rounded" type="submit">Modificar</button>
                        </div>
                        <div className="flex justify-center">
                            <button className="bg-gray-500 text-white px-4 py-2 rounded" type="button"  onClick={() => router.push('/persona')}>Cancelar</button>
                        </div>
                </form>
            </main>
        </>
    );
}