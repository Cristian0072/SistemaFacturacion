import { useState } from 'react';
import Link from 'next/link';
import Cookies from 'js-cookie';
import Image from 'next/image';

export default function Menu() {
    //variable de estado para guardar el estado del menu amburguesa
    const [abierto, setAbierto] = useState(false);

    const cerrarSesion = () => {
        Cookies.remove('token');
        Cookies.remove('usuario');
        Cookies.remove('expira');
        Cookies.remove('external');
    };
    //funcion para abrir y cerrar el menu amburguesa
    const menu_amburguesa = () => setAbierto(!abierto);

    return (
        <div>
            <nav className="fixed top-0 left-0 right-0 bg-white shadow-md p-2 flex justify-between items-center">
                <button onClick={menu_amburguesa} className="focus:outline-none">
                    <Image src="/img/ambug.png" alt="Menu Amburguesa" width={30} height={30} />
                </button>
                <div className='flex items-center'>
                    <Image className="mr-1" src="/img/facturacion.png" alt="Facturacion" width={50} height={50} />
                    <h3 className='text-2x1 text-black font-bold'>
                        SISTEMA DE FACTURACION
                    </h3>
                </div>
                {abierto && (
                    <div className="fixed inset-0 bg-black bg-opacity-50 z-40" onClick={menu_amburguesa}>
                        <div className="fixed top-0 left-0 bottom-0 w-60 bg-white p-4 z-50">
                            <h2 className="text-2x1 text-center text-black font-bold mb-8">PANEL DE ADMINISTRACION</h2>
                            <ul>
                                <li className="mb-2 text-black font-bold">
                                    <Link href="/persona" className="block p-3 hover:bg-green-300 rounded border border-green-500">
                                        Administración de Personas
                                    </Link>
                                </li>
                                <li className="mb-2 text-black font-bold">
                                    <Link href="/producto" className="block p-3 hover:bg-green-300 rounded border border-green-500">
                                        Administración de Productos
                                    </Link>
                                </li>
                                <li className="mb-40 text-black font-bold">
                                    <Link href="/cuenta" className="block p-3 hover:bg-green-300 rounded border border-green-500">
                                        Usuario
                                    </Link>
                                </li>
                                <li className='mb-2 text-black font-bold'>
                                    <Link href="/sesion" onClick={cerrarSesion} className='block p-3 hover:bg-red-300 rounded border border-red-500'>
                                        Cerrar sesión
                                    </Link>
                                </li>
                            </ul>
                        </div>
                    </div>
                )}
            </nav>
        </div>
    );
}