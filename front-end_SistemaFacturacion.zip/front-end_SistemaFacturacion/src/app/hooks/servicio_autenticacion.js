import { POST } from './Conexion';

export async function inicio_sesion(data) {
    let datos = null;
    try {
        datos = await POST("sesion", data);
    } catch (error) {
        // retorna el error
        console.log(error.response.data);
        return error.response.data;
    }
    return datos.data;
}