import Cookies from 'js-cookie';
import swal from 'sweetalert';
// Verificar la expiración del token
export function verificarExpiracionToken(router) {
    // Obtener la fecha de expiracion del token
    let expiracion = Cookies.get('expira');

    // Obtener la fecha/hora actual
    let ahora = Date.now() / 1000;
    console.log("Expiración: " + expiracion);
    console.log("Ahora: " + ahora);

    // Si el token ha expirado...
    if (ahora >= expiracion) {
        // Mostrar un mensaje
        swal({
            title: "Sesión expirada",
            text: "Tu sesión ha expirado. Por favor, inicia sesión de nuevo",
            icon: "info",
            button: "Aceptar",
            timer: 10000,
            closeOnEsc: true
        });

        // Redirigir al panel de inicio de sesión
        Cookies.remove('token');
        Cookies.remove('usuario');
        Cookies.remove('expira');
        Cookies.remove('external');
        
        router.push('/sesion');
        router.refresh();
        return false;
    }
    return true;
}