// Función para formatear la fecha
export function formatoFecha(fechastr) {

    const fecha = new Date(fechastr);

    // Opciones de formato para mostrar la fecha como "dd de mes de yyyy"
    const opciones = { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' };

    // Retornar la fecha formateada según las opciones "dd de mes de yyyy"
    return fecha.toLocaleDateString('es-ES', opciones);
}
