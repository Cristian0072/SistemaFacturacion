const URL = process.env.URL_API;
import axios from "axios";

// método genérico GET con token
export const GET = async (ruta, token = "NONE") => {
    //si no existe token
    let headers = {
        headers: {
            "Accept": "application/json"
        }
    }
    //si existe token
    if (token !== "NONE") {
        headers = {
            headers: {
                "Accept": "application/json",
                "X-Access-Token": token,
            }
        }
    }
    return await axios.get(URL + ruta, headers);
}

// método genérico POST con token
export const POST = async (ruta, data, token = "NONE") => {
    //si no existe token
    let headers = {
        headers: {
            "Accept": "application/json",
            "Content-Type": "application/json"
        }
    }
    //si existe token
    if (token !== "NONE") {
        headers = {
            headers: {
                "Accept": "application/json",
                "X-Access-Token": token,
            }
        }
    }
    return await axios.post(URL + ruta, data, headers);
}

export const POST_ARCHIVOS = async (ruta, data, token = "NONE") => {
    let headers = {};

    if (token !== "NONE") {
        headers = {
            headers: {
                "Accept": "application/json",
                "X-Access-Token": token,
                // No necesitas Content-Type aquí para subir archivos
            }
        };
    }

    // Si estás subiendo un archivo, utiliza FormData en lugar de enviar JSON
    if (data instanceof FormData) {
        headers.headers["Content-Type"] = "multipart/form-data";
    }

    return await axios.post(URL + ruta, data, headers);
};