//servicios para el manejo de la API de persona
import Cookies from 'js-cookie';
import { GET, POST, POST_ARCHIVOS } from './Conexion';

//servicio para listar personas
export async function listar_personas() {
    let datos = null;
    //manejar errores "CONEXION CON EL BACKEND"
    try {
        //obtener token
        let token = Cookies.get('token');
        datos = await GET("persona/usuario", token);

    } catch (error) {
        return error.response.data;
    }
    return datos.data;
}

//servicio para obtener persona por external
export async function obtener_persona(external) {
    let datos = null;
    //manejar errores "CONEXION CON EL BACKEND"
    try {
        //obtener token
        let token = Cookies.get("token");
        datos = await GET("persona/" + external, token);

    } catch (error) {
        return error.response.data;
    }
    return datos.data;
}

//servicio para crear persona
export async function guardar_persona(info) {
    let datos = null;
    //manejar errores "CONEXION CON EL BACKEND"
    try {
        //obtener token
        let token = Cookies.get("token");
        datos = await POST("persona/guardar", info, token);
    } catch (error) {
        return error.response.data;
    }
    return datos.data;
}

//servicio para modificar persona
export async function modificar_persona(external,info) {
    let datos = null;
    //manejar errores "CONEXION CON EL BACKEND"
    try {
        //obtener token
        let token = Cookies.get("token");
        datos = await POST("persona/modificar/"+external, info, token);
        //actualizar external en cookies
        Cookies.set('external', datos.data.external);
    } catch (error) {
        console.log(error);
        return error.response.data;
    }
    return datos.data;
}

//servicio para listar archivos de persona
export async function obtener_archivos(external) {
    let datos = null;
    //manejar errores "CONEXION CON EL BACKEND"
    try {
        //obtener token
        let token = Cookies.get('token');
        datos = await GET("persona/archivo/" + external, token);
    } catch (error) {
        return error.response.data;
    }
    return datos.data;
}
//servicio para obtener archivo de perfil
export async function archivo_perfil(external) {
    let datos = null;
    try {
        //obtener token
        let token = Cookies.get('token');
        datos = await GET("persona/foto/" + external, token);
    } catch (error) {
        return error.response.data;
    }
    return datos.data;
}

export async function guardar_archivo(info) {
    let datos = null;
    //manejar errores "CONEXION CON EL BACKEND"
    try {
        //obtener token
        let token = Cookies.get("token");
        datos = await POST_ARCHIVOS("persona/archivo", info, token);
    } catch (error) {
        return error.response.data;
    }
    return datos.data;
}