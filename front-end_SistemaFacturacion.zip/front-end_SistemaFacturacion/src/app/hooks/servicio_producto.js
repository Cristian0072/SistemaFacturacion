//servicios para el manejo de la API de producto
import Cookies from 'js-cookie';
import { GET, POST } from './Conexion';

//servicio para listar personas
export async function listar_productos() {
    let datos = null;
    //manejar errores "CONEXION CON EL BACKEND"
    try {
        //obtener token
        let token = Cookies.get('token');
        datos = await GET("producto", token);

    } catch (error) {
        return error.response.data;
    }
    return datos.data;
}


//servicio para listar productos por estado
export async function listar_productos_estado(estado) {
    let datos = null;
    //manejar errores "CONEXION CON EL BACKEND"
    try {
        //obtener token
        let token = Cookies.get('token');
        datos = await POST("producto/estado", estado,token);

    } catch (error) {
        return error.response.data;
    }
    return datos.data;
}

//servicio para obtener producto por external
export async function obtener_producto(external) {
    let datos = null;
    //manejar errores "CONEXION CON EL BACKEND"
    try {
        //obtener token
        let token = Cookies.get("token");
        datos = await GET("producto/" + external, token);

    } catch (error) {
        return error.response.data;
    }
    return datos.data;
}

//servicio para guardar producto
export async function guardar_producto(info) {
    let datos = null;
    //manejar errores "CONEXION CON EL BACKEND"
    try {
        //obtener token
        let token = Cookies.get("token");
        datos = await POST("producto/guardar", info, token);
    } catch (error) {
        return error.response.data;
    }
    return datos.data;
}

//servicio para guardar producto
export async function modificar_persona(info) {
    let datos = null;
    //manejar errores "CONEXION CON EL BACKEND"
    try {
        //obtener token
        let token = Cookies.get("token");
        datos = await POST("producto/modificar", info, token);
    } catch (error) {
        return error.response.data;
    }
    return datos.data;
}
