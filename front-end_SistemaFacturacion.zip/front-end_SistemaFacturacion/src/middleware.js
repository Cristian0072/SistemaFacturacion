import { NextResponse } from 'next/server'

// Esta función se ejecutará en cada solicitud a la aplicación
export default async function Middleware(request) {
    console.log('Middleware ejecutado');
    let token = request.cookies.get('token');
    let usuario = request.cookies.get('usuario');
    let path = request.nextUrl.pathname; // obtiene la ruta de la solicitud
    console.log('Path:', path);

    /// Define las rutas protegidas y la ruta de inicio de sesión
    const rutasProtegidas = ['/panel', '/producto','/persona'];
    const rutaSesion = '/sesion';

    // Si el usuario no está logeado y trata de acceder a una ruta protegida, redirige a la página de inicio de sesión
    if (!token || !usuario) {
        // Si la ruta no es la de inicio de sesión, redirige a la página de inicio de sesión
        if (rutasProtegidas.some(ruta => path.startsWith(ruta))) {
            return NextResponse.redirect(process.env.URL_FRONT + 'sesion');
        }
        // Si el usuario está logeado y trata de acceder a la página de inicio de sesión, redirige al panel
    } else if (token && usuario && path.startsWith(rutaSesion)) {
        return NextResponse.redirect(process.env.URL_FRONT + 'panel');
    } else {
        // Continúa con la solicitud normal
        return NextResponse.next();
    }
}
//aplica el middleware a todas las rutas
export const config = {
    matcher: ['/:path*'] // aplica el middleware a todas las rutas
}